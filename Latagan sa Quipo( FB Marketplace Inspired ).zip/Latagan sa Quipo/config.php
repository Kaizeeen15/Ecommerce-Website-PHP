<?php

$conn = mysqli_connect('localhost','root','','database') or die('connection failed');

?>